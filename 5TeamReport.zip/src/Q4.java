/*
        *
        **
        ***
        ****
        *****

        *****
        ****
        ***
        **
        *
*/

public class Q4 {
    public static void main(String[] args){

        int a,j;

        for (a=0; a<=5; a++){
            for(j=0; j<a; j++){
                System.out.print("*");

            }
            System.out.println();
        }
        for(a=0; a<=5; a++){
            for(j=5; j>a; j--) {
                System.out.print("*");
            }
            System.out.println();
        }

        }


    }

